# AIP Type Mapping for MVP
Version: 2.1  
Date: 2026-04-13

## 1. Purpose
Map task situation to MVP AIP types.

---

## 2. Mapping table

| Situation | Recommended AIP Type | Notes |
|---|---|---|
| project-level context / priorities | AIP_ROOT | root control artifact |
| scope clarification / planning / review planning | AIP_PLAN | prefer PLAN when uncertain |
| actual execution / actual review / actual update | AIP_EXEC | use EXEC when scope/output are ready |
| private/local support note | AIP_LOCAL | optional only |

---

## 3. Key rule
Do not bring back old main branches like Shared / PM / Member / META as primary AIP types in MVP.

If coordination/PM-like concerns exist, express them:
- inside AIP_ROOT
- inside PLAN/EXEC sections
- or via procedural/workspace artifacts

without expanding the main AIP type system.
