# AIP Forge Package — MVP Aligned Update Summary
Version: 2.1  
Date: 2026-04-13

## Mục đích
Đây là bản update từ package v2.0, tiếp tục align với design mới của **AI Work System MVP** và phản ánh vòng review vừa rồi.

## Phạm vi update trong package này
Package này tiếp tục tập trung vào:
- **AIP templates**
- **Q&A flow / question bank để tạo AIP**
- **một số rule cốt lõi về lifecycle / workspace / type mapping**
- **skill create-aip**

## Thay đổi chính từ v2.0 → v2.1

### 1. AIP_PLAN template
Đã bổ sung:
- `Task Classification`
- chia `References to Read First` thành:
  - Truth First
  - Wiki First
  - Optional Supporting Refs
- tách `Open Questions` và `Risks / Constraints`
- thêm `Step Output / Execution Artifact`

### 2. AIP_EXEC template
Đã bổ sung:
- `Execution Input Package`
- `Known Open Points`
- tách `Self-check / Review Points` và `Finalization Notes`
- thêm rule chung về Workspace behavior để tránh lặp

### 3. Question bank
Đã bổ sung:
- `Minimal live questioning order`
- nhóm câu hỏi riêng cho:
  - Workspace necessity
  - Truth / Wiki / History reading
- `Stop asking condition` rõ hơn

### 4. create-aip skill
Đã nâng từ guideline ngắn thành **executable skill spec** hơn, gồm:
- Execution Flow
- Inputs
- Outputs
- Fallback / failure behavior
- clearer stop condition

## Những gì vẫn giữ nguyên
- worldview mới:
  - **AIP = AI Implementation Plan**
  - `AIP_ROOT / PLAN / EXEC / LOCAL`
  - stable AIP
  - Workspace-based execution
  - Active Step Context
  - Wiki-first model

## Nội dung package
- `aip_templates/`
- `guides/`
- `rules/`
- `skills/create-aip/`

## Khuyến nghị review
Nên check trước:
1. `aip_templates/AIP_PLAN_TEMPLATE_MVP.md`
2. `aip_templates/AIP_EXEC_TEMPLATE_MVP.md`
3. `guides/AIP_QA_Question_Bank_MVP.md`
4. `skills/create-aip/SKILL.md`
