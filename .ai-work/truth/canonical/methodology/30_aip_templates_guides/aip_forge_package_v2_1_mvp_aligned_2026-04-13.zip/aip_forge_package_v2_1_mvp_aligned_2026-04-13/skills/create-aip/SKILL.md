---
name: create-aip
description: Create an AIP (AI Implementation Plan) aligned with the AI Work System MVP
user-invocable: true
---

# SKILL: Create AIP (MVP-aligned)

**Version:** v2.1  
**Date:** 2026-04-13

## 1. Purpose
This skill creates an AIP aligned with the new **AI Work System MVP**.

It must align with:
- SOP-first
- AI Work Contract
- AIP_ROOT / PLAN / EXEC / LOCAL
- Active Step Context
- Workspace-based execution
- Wiki-first knowledge usage

---

## 2. Inputs this skill may use
- current task/request from user
- `truth/SOP_MASTER.md`
- `truth/AI_WORK_CONTRACT.md`
- `truth/AIP_ROOT.md`
- relevant truth/wiki refs if already provided
- existing AIP if this is update/replan rather than brand-new create

---

## 3. Outputs of this skill
- chosen AIP type
- clarified understanding draft
- unresolved key questions list if any
- drafted AIP content aligned with the correct template

---

## 4. Core rules

### Rule 1
Use **AI Implementation Plan**, not AI Instruction Plan.

### Rule 2
If uncertain between PLAN and EXEC, choose PLAN.

### Rule 3
Do not create overly large AIPs that mix many unrelated outputs.

### Rule 4
AIP is stable control, not runtime notebook.

### Rule 5
Each step should be written so it can later be materialized into **Active Step Context**.

### Rule 6
If task appears outside current MVP scope, confirm before proceeding.

---

## 5. Execution flow

```text
1. Read task/request
2. Infer understanding draft
3. Decide if AIP is needed
4. Decide AIP type: ROOT / PLAN / EXEC / LOCAL
5. Ask minimal clarification only if needed
6. Select correct template
7. Draft AIP
8. Run self-check
9. Output draft AIP
```

---

## 6. Clarification behavior

### Infer-first
Always infer first from the request.
Do not ask broad questions if enough can already be inferred.

### Ask minimally
Only ask the smallest set of questions needed to create a safe AIP.

### Stop condition
Stop asking when enough is clear to:
- choose AIP type
- define scope/output
- choose refs
- judge workspace need
- create a safe draft

---

## 7. Failure / fallback behavior

### If uncertain between PLAN and EXEC
Choose PLAN.

### If output types are mixed
Suggest splitting into more than one AIP.

### If scope is too broad
Propose narrowing scope or creating a higher-level plan first.

### If task exceeds MVP scope
Ask for confirmation before continuing.

### If references are unclear but task can still proceed
Draft visible Open Questions / Risks instead of pretending certainty.

---

## 8. References inside this package
- `guides/GUIDE_Create_AIP_MVP.md`
- `guides/AIP_QA_Flow_MVP.md`
- `guides/AIP_QA_Question_Bank_MVP.md`
- `rules/AIP_TYPE_MAPPING_MVP.md`
- `rules/AIP_LIFECYCLE_RULE_MVP.md`
- `rules/AIP_WORKSPACE_STRUCTURE_RULE_MVP.md`
- `aip_templates/AIP_ROOT_TEMPLATE_MVP.md`
- `aip_templates/AIP_PLAN_TEMPLATE_MVP.md`
- `aip_templates/AIP_EXEC_TEMPLATE_MVP.md`
- `aip_templates/AIP_LOCAL_TEMPLATE_MVP.md`

---

## 9. Output quality checklist
Before finalizing an AIP, verify:
- correct AIP type chosen
- objective is clear
- scope/non-scope visible
- expected outputs visible
- references to read first visible
- workspace need considered
- step structure complete enough
- PLAN → EXEC handoff sufficient if this is PLAN
- no runtime findings/queue/open questions wrongly embedded as if AIP were a workspace file
