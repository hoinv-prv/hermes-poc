---
artifact_type: aip_exec
artifact_id: AIP-EXEC-001
title: <title>
status: draft
project: <project-name>
owner: <optional>
root_aip: AIP-ROOT
plan_source: AIP-PLAN-001
updated_at: YYYY-MM-DD
---

# AIP_EXEC — <title>

## Objective
Mô tả mục tiêu execution của task/workstream này.

## Execution Scope
### In Scope
- ...

### Out of Scope
- ...

## Expected Outputs
- Output 1:
- Output 2:

## Execution Input Package
### Plan Source
- `aip/plans/AIP-PLAN-...` (nếu có)

### Required Truth Inputs
- `truth/...`

### Required Wiki Inputs
- `wiki/...`

### Required Workspace Preconditions
- [ ] Workspace created if needed
- [ ] Active Step Context available
- [ ] Relevant queue/findings/open questions available when applicable

## References to Read First
- `truth/...`
- `wiki/...`
- `procedural/...`
- `aip/plans/AIP-PLAN-...` (nếu có)

## Current Risks / Constraints
- ...

## Known Open Points
- ...
- ...

## Workspace Execution Rule
All execution steps should update workspace artifacts when applicable:
- Active Step Context
- Queue
- Findings
- Open Questions
- Draft Output
- Capture Inbox

## Execution Steps

### Step: STEP-01 — <step title>
Objective:
...

Recommended Mode:
Executing

Applicable Guidelines:
- ...

Recommended Skills:
- ...

Inputs:
- ...

Expected Outputs:
- ...

Done Condition:
...

Notes / Constraints:
...

Workspace Actions:
- add only step-specific actions here

### Step: STEP-02 — <step title>
Objective:
...

Recommended Mode:
Reviewing

Applicable Guidelines:
- ...

Recommended Skills:
- ...

Inputs:
- ...

Expected Outputs:
- ...

Done Condition:
...

Notes / Constraints:
...

Workspace Actions:
- add only step-specific actions here

## Done Criteria
- [ ] Output đúng loại, đúng scope
- [ ] Output bám PLAN handoff hoặc direct execution justification
- [ ] Open points không còn bị che giấu
- [ ] Final output sẵn sàng cho downstream / review

## Self-check / Review Points
- ...
- ...

## Finalization Notes
- ...
- ...

## Re-plan Rule
Nếu cần thay đổi macro scope hoặc expected output:
- không silently drift
- tạo explicit re-plan / update AIP
