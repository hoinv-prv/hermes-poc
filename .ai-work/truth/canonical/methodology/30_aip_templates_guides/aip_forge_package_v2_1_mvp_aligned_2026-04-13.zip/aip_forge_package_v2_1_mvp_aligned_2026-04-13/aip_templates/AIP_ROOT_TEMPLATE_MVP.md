---
artifact_type: aip_root
artifact_id: AIP-ROOT
title: Project Root AIP
status: active
project: <project-name>
updated_at: YYYY-MM-DD
---

# AIP_ROOT — Project Root AIP

## Objective
Mô tả ngắn mục tiêu AI working của project này.

## Project Scope
### In Scope
- ...

### Out of Scope
- ...

## Project Priorities
- ...
- ...

## Core References
- `truth/SOP_MASTER.md`
- `truth/AI_WORK_CONTRACT.md`
- ...
- ...

## Constraints / Assumptions
- ...

## Notes
- ...

## Guidance for downstream AIPs
- Các AIP task-level phải bám scope/priorities của file này
- Nếu task vượt ngoài scope hiện tại, cần confirm lại trước khi tạo AIP chi tiết
