---
artifact_type: aip_local
artifact_id: AIP-LOCAL-001
title: <title>
status: draft
project: <project-name>
owner: <optional>
updated_at: YYYY-MM-DD
---

# AIP_LOCAL — <title>

## Objective
- ...

## Notes
- ...

## Personal Constraints / Reminders
- ...

## Local Execution Notes
- ...

## Rule
AIP_LOCAL là tùy chọn.
Không dùng thay cho AIP shared/official trong workflow chính của MVP.
