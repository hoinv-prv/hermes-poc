# AIP Q&A Flow for MVP
Version: 2.1  
Date: 2026-04-13

## 1. Purpose
Flow chuẩn để AI hỏi làm rõ trước khi tạo AIP theo worldview mới của MVP.

---

## 2. Core rule
AI không được hỏi lại từ đầu như chưa có gì.

AI phải:
1. đọc mô tả task
2. infer classification draft
3. chỉ hỏi lại những điểm thực sự quan trọng còn mơ hồ
4. hỏi từng câu một nếu cần

---

## 3. Standard flow

```text
Receive task
    ↓
Infer understanding draft
    ↓
Decide whether AIP is needed
    ↓
Classify PLAN or EXEC
    ↓
Clarify scope / output / references / workspace need
    ↓
Choose AIP type
    ↓
Draft AIP
```

---

## 4. Classification draft format

```md
## Tôi hiểu task như sau

- Need AIP?: [yes / no / probably]
- Suggested AIP type: [AIP_PLAN / AIP_EXEC / AIP_LOCAL]
- Why:
- Expected output:
- Scope draft:
- Workspace need draft:
- Key uncertainty:
```

If enough is clear:
> Tôi sẽ tạo AIP theo hướng trên.

If not enough:
> Tôi cần confirm 1 điểm trước khi tạo AIP.

---

## 5. Question priority order

Nếu còn nhiều điểm chưa rõ, hỏi theo thứ tự:

1. Có cần AIP không?
2. PLAN hay EXEC?
3. Output chính là gì?
4. Scope tới đâu?
5. Input/reference nào là bắt buộc?
6. Có cần workspace không?
7. Biggest unresolved risk là gì?

---

## 6. Confirm-question style

Use:

> **[Điểm cần xác nhận]**: Tôi hiểu là _[assumption]_  
> - **Yes**  
> - **Edit:** ...  
> - **Not decided yet**

Not open-ended broad questioning if inference is already possible.

---

## 7. If user says “Not decided yet”
AI phải:
- không bỏ qua
- ghi vào Open Questions / Risks
- nếu ảnh hưởng lớn đến execution → ưu tiên PLAN
- nếu ảnh hưởng nhỏ và task vẫn chạy được → allow proceed with visible note

---

## 8. Stop condition
Dừng hỏi khi đủ để tạo AIP an toàn.

Không hỏi thêm chỉ để tài liệu đẹp hơn.
Phần chưa rõ nhưng không block có thể đưa vào:
- Open Questions
- Risks / Constraints
- Known Open Points
