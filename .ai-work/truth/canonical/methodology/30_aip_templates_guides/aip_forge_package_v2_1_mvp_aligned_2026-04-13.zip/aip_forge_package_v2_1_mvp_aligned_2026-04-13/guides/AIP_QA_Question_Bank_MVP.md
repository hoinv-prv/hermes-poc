# AIP Question Bank for MVP
Version: 2.1  
Date: 2026-04-13

## 1. Purpose
Bộ câu hỏi hỗ trợ AI tạo AIP theo design mới của MVP.

Bộ này không phải questionnaire để hỏi hết theo thứ tự.
Nó là ngân hàng câu hỏi để chọn đúng vài câu thật sự cần.

---

## 2. Minimal live questioning order

Khi cần hỏi thật ít mà vẫn đủ để tạo AIP, ưu tiên hỏi theo thứ tự:

1. Need AIP?
2. PLAN or EXEC?
3. Main output?
4. Scope / out-of-scope?
5. Must-read refs?
6. Workspace needed?
7. Biggest unresolved risk?

Nếu đã đủ rõ ở một điểm, không cần hỏi tiếp điểm đó.

---

## 3. Level 0 — Need AIP?

### Q0-1
Task này có nhiều bước / dependency / output có cấu trúc / handoff không?

### Q0-2
Nếu không tạo AIP, AI và người có dễ hiểu sai scope hoặc output không?

### Q0-3
Task này có cần reusable execution control không?

If mostly no → maybe no full AIP needed.

---

## 4. Level 1 — PLAN hay EXEC?

### Q1-1
Mục tiêu chính hiện tại là:
- làm rõ scope/output/approach?
- hay thực hiện output thật?

### Q1-2
Objective đã đủ rõ để bắt đầu execution chưa?

### Q1-3
Expected output đã đủ rõ chưa?

### Q1-4
Nếu làm ngay bây giờ, risk làm sai hướng có cao không?

#### Decision hint
- Nếu còn mơ hồ đáng kể → PLAN
- Nếu đủ rõ để làm ngay → EXEC
- Nếu nghi ngờ → PLAN

---

## 5. Level 2 — Scope / Output

### Q2-1
Output chính của task là gì?

### Q2-2
Ai sẽ dùng output đó?

### Q2-3
Task bắt đầu từ đâu và kết thúc khi nào?

### Q2-4
Có gì rõ ràng là out-of-scope không?

### Q2-5
Task này là một deliverable/workstream riêng hay đang bị gộp quá nhiều output khác loại?

#### Split hint
Nếu có nhiều output khác loại → nên tách AIP.

---

## 6. Level 3 — References / Constraints / Risks

### Q3-1
Những file/reference nào bắt buộc phải đọc trước?

### Q3-2
Có canonical source hoặc truth artifact nào phải ưu tiên không?

### Q3-3
Có dependency / blocker / approval point nào quan trọng không?

### Q3-4
Có assumption nào được phép tạm chấp nhận không?

### Q3-5
Nếu task này chạy tiếp, điểm nào dễ gây rework nhất?

---

## 7. Level 4 — Workspace necessity

### Q4-1
Task này có nhiều hơn 1 source chính không?

### Q4-2
Task này có nhiều bước reasoning không?

### Q4-3
Có dependency / scope decision cần giữ lại rõ ràng không?

### Q4-4
Có khả năng resume / handoff không?

### Q4-5
Có cần queue hoặc capture inbox không?

#### Decision hint
Nếu nhiều câu trả lời là yes → workspace likely needed.

---

## 8. Level 5 — Truth / Wiki / History reading

### Q5-1
Nguồn authoritative của task này là gì?

### Q5-2
Phần nào có thể hiểu nhanh từ wiki?

### Q5-3
Phần nào chỉ nên lấy như reference/guidance?

### Q5-4
Có cần tra history không, hay history chỉ là optional fallback?

### Q5-5
Có risk nào nếu AI tin vào summary/reference mà không verify lại source không?

---

## 9. Level 6 — PLAN → EXEC handoff quality

Use when creating/reviewing AIP_PLAN.

### Q6-1
PLAN đã đủ objective chưa?

### Q6-2
PLAN đã ghi scope / non-scope chưa?

### Q6-3
PLAN đã nêu expected outputs chưa?

### Q6-4
PLAN đã chỉ ra references to read first chưa?

### Q6-5
PLAN đã có execution skeleton chưa?

### Q6-6
PLAN đã có open questions / risks chưa?

### Q6-7
PLAN đã có done criteria / review points chưa?

If many answers are no → PLAN not ready for EXEC handoff.

---

## 10. Level 7 — AIP quality check

### Q7-1
AIP này có đúng loại chưa?
### Q7-2
AIP này có quá to không?
### Q7-3
AIP này có đang ôm runtime state lẽ ra phải ở Workspace không?
### Q7-4
Step structure đã đủ để materialize Active Step Context chưa?
### Q7-5
AIP này có khiến EXEC phải re-plan lại từ đầu không?

---

## 11. Stop asking condition

Dừng hỏi khi:
- đủ để chọn đúng AIP type
- đủ để draft scope / outputs / refs / risks
- đủ để quyết định workspace need
- phần chưa rõ còn lại không block việc tạo AIP an toàn

Không hỏi tiếp chỉ để tài liệu đầy đủ hơn về mặt hình thức.
