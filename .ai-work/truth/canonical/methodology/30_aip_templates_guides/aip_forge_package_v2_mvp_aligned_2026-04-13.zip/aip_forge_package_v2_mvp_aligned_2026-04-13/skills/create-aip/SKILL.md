---
name: create-aip
description: Create an AIP (AI Implementation Plan) aligned with the AI Work System MVP
user-invocable: true
---

# SKILL: Create AIP (MVP-aligned)

**Version:** v2.0  
**Date:** 2026-04-13

## 1. Purpose
This skill creates an AIP aligned with the new **AI Work System MVP**.

It must align with:
- SOP-first
- AI Work Contract
- AIP_ROOT / PLAN / EXEC / LOCAL
- Active Step Context
- Workspace-based execution
- Wiki-first knowledge usage

---

## 2. What this skill should produce
Depending on the task, this skill should create one of:
- `AIP_ROOT`
- `AIP_PLAN`
- `AIP_EXEC`
- optional `AIP_LOCAL`

---

## 3. Core rules

### Rule 1
Use **AI Implementation Plan**, not AI Instruction Plan.

### Rule 2
If uncertain between PLAN and EXEC, choose PLAN.

### Rule 3
Do not create overly large AIPs that mix many unrelated outputs.

### Rule 4
AIP is stable control, not runtime notebook.

### Rule 5
Each step should be written so it can later be materialized into **Active Step Context**.

---

## 4. Inputs this skill should clarify
Minimum clarification:
- What is the task objective?
- Is the task mainly planning or execution?
- What is the expected output?
- What is in-scope / out-of-scope?
- What references must be read first?
- What open questions / risks remain?

Use infer-first and ask only the smallest necessary follow-up questions.

---

## 5. References inside this package
- `guides/GUIDE_Create_AIP_MVP.md`
- `guides/AIP_QA_Flow_MVP.md`
- `guides/AIP_QA_Question_Bank_MVP.md`
- `rules/AIP_TYPE_MAPPING_MVP.md`
- `rules/AIP_LIFECYCLE_RULE_MVP.md`
- `rules/AIP_WORKSPACE_STRUCTURE_RULE_MVP.md`
- `aip_templates/AIP_ROOT_TEMPLATE_MVP.md`
- `aip_templates/AIP_PLAN_TEMPLATE_MVP.md`
- `aip_templates/AIP_EXEC_TEMPLATE_MVP.md`
- `aip_templates/AIP_LOCAL_TEMPLATE_MVP.md`

---

## 6. Output quality checklist
Before finalizing an AIP, verify:
- correct AIP type chosen
- objective is clear
- scope/non-scope visible
- expected outputs visible
- references to read first visible
- step structure complete enough
- PLAN → EXEC handoff sufficient if this is PLAN
- no runtime findings/queue/open questions wrongly embedded as if AIP were a workspace file
