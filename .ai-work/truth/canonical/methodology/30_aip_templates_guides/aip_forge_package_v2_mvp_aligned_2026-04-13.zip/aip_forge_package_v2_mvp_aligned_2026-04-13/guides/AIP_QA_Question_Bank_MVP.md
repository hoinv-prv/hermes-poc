# AIP Question Bank for MVP
Version: 2.0  
Date: 2026-04-13

## 1. Purpose
Bộ câu hỏi hỗ trợ AI tạo AIP theo design mới của MVP.

Bộ này không phải questionnaire để hỏi hết theo thứ tự.
Nó là ngân hàng câu hỏi để chọn đúng vài câu thật sự cần.

---

## 2. Level 0 — Need AIP?

### Q0-1
Task này có nhiều bước / dependency / output có cấu trúc / handoff không?

### Q0-2
Nếu không tạo AIP, AI và người có dễ hiểu sai scope hoặc output không?

### Q0-3
Task này có cần reusable execution control không?

If mostly no → maybe no full AIP needed.

---

## 3. Level 1 — PLAN hay EXEC?

### Q1-1
Mục tiêu chính hiện tại là:
- làm rõ scope/output/approach?
- hay thực hiện output thật?

### Q1-2
Objective đã đủ rõ để bắt đầu execution chưa?

### Q1-3
Expected output đã đủ rõ chưa?

### Q1-4
Nếu làm ngay bây giờ, risk làm sai hướng có cao không?

#### Decision hint
- Nếu còn mơ hồ đáng kể → PLAN
- Nếu đủ rõ để làm ngay → EXEC
- Nếu nghi ngờ → PLAN

---

## 4. Level 2 — Scope / Output

### Q2-1
Output chính của task là gì?

### Q2-2
Ai sẽ dùng output đó?

### Q2-3
Task bắt đầu từ đâu và kết thúc khi nào?

### Q2-4
Có gì rõ ràng là out-of-scope không?

### Q2-5
Task này là một deliverable/workstream riêng hay đang bị gộp quá nhiều output khác loại?

#### Split hint
Nếu có nhiều output khác loại → nên tách AIP.

---

## 5. Level 3 — References / Constraints / Risks

### Q3-1
Những file/reference nào bắt buộc phải đọc trước?

### Q3-2
Có canonical source hoặc truth artifact nào phải ưu tiên không?

### Q3-3
Có dependency / blocker / approval point nào quan trọng không?

### Q3-4
Có assumption nào được phép tạm chấp nhận không?

### Q3-5
Nếu task này chạy tiếp, điểm nào dễ gây rework nhất?

---

## 6. Level 4 — PLAN → EXEC handoff quality

Use when creating/reviewing AIP_PLAN.

### Q4-1
PLAN đã đủ objective chưa?

### Q4-2
PLAN đã ghi scope / non-scope chưa?

### Q4-3
PLAN đã nêu expected outputs chưa?

### Q4-4
PLAN đã chỉ ra references to read first chưa?

### Q4-5
PLAN đã có execution skeleton chưa?

### Q4-6
PLAN đã có open questions / risks chưa?

### Q4-7
PLAN đã có done criteria / review points chưa?

If many answers are no → PLAN not ready for EXEC handoff.

---

## 7. Level 5 — AIP quality check

### Q5-1
AIP này có đúng loại chưa?
### Q5-2
AIP này có quá to không?
### Q5-3
AIP này có đang ôm runtime state lẽ ra phải ở Workspace không?
### Q5-4
Step structure đã đủ để materialize Active Step Context chưa?
### Q5-5
AIP này có khiến EXEC phải re-plan lại từ đầu không?

---

## 8. Recommended usage
- pick only the smallest set of questions needed
- infer first, ask later
- ask one question at a time if clarification is needed
- if still uncertain between PLAN and EXEC, choose PLAN
