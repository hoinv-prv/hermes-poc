# GUIDE — Create AIP for AI Work System MVP
Version: 2.0  
Date: 2026-04-13

## 1. Purpose
Guide này dùng để tạo AIP theo design mới của **AI Work System MVP**.

Nó tập trung vào:
- quyết định có cần AIP hay không
- phân loại đúng `AIP_ROOT / PLAN / EXEC / LOCAL`
- hỏi đúng các câu clarifying quan trọng
- tránh tạo AIP quá to hoặc quá nhỏ
- align với:
  - SOP
  - AI Work Contract
  - AIP_ROOT
  - Workspace
  - Active Step Context
  - Wiki-first model

---

## 2. Core principles

### 2.1 Clarification-first, but infer-first
AI phải:
1. đọc mô tả task hiện có
2. infer trước những gì đã rõ
3. chỉ hỏi lại điểm thật sự quan trọng còn chưa rõ

### 2.2 AIP type and Mode are different
- AIP type = control phase
- Mode = reasoning posture

### 2.3 PLAN before EXEC when needed
Nếu objective/scope/output chưa đủ rõ → ưu tiên PLAN

### 2.4 Stable AIP, dynamic Workspace
AIP không phải runtime notebook.
Nếu task cần nhiều execution state → dùng Workspace

### 2.5 Medium-sized granularity
AIP nên map tới một deliverable hoặc workstream vừa phải.
Không tạo 1 AIP cho từng micro-task.
Không gộp quá nhiều output khác loại vào 1 AIP.

---

## 3. Decision flow

```text
Receive task/request
    ↓
Step 0. Decide if AIP is needed
    ↓
Step 1. Infer task understanding draft
    ↓
Step 2. Confirm PLAN or EXEC
    ↓
Step 3. Confirm scope / output / references
    ↓
Step 4. Choose AIP type
    ↓
Step 5. Draft AIP using correct template
    ↓
Step 6. Review readiness / handoff quality
```

---

## 4. Step 0 — Decide if AIP is needed

Tạo AIP nếu task có một hoặc nhiều dấu hiệu:
- nhiều bước
- dependency / handoff
- output có cấu trúc
- cần review / coordination
- cần reusable execution control
- cần workspace nhiều bước

Không cần full AIP nếu task cực nhỏ và có thể xử lý trực tiếp theo Contract + Wiki + Mode.

---

## 5. Step 1 — Infer task understanding draft

AI phải tóm tắt nhanh:
- task là gì
- output dự kiến là gì
- ai sẽ dùng output
- scope có vẻ tới đâu
- chỗ nào còn chưa rõ

Không hỏi lại như chưa có thông tin.

---

## 6. Step 2 — Confirm PLAN or EXEC

### Chọn PLAN khi:
- mục tiêu chính là làm rõ scope / output / approach / references / review points
- hoặc risk làm sai hướng còn cao

### Chọn EXEC khi:
- objective đã rõ
- output đã rõ
- scope đủ rõ để bắt đầu
- phần chưa rõ còn lại chỉ là refinement cục bộ

### Fallback
Nếu còn nghi ngờ → PLAN

---

## 7. Step 3 — Confirm scope / output / references

Tối thiểu cần làm rõ:
- task objective
- in-scope / out-of-scope
- expected outputs
- references to read first
- open questions / risks
- review points nếu có

---

## 8. Step 4 — Choose AIP type

### AIP_ROOT
Dùng cho project/root context.

### AIP_PLAN
Dùng cho:
- planning
- scope clarification
- review planning
- execution preparation

### AIP_EXEC
Dùng cho:
- actual execution
- actual review
- actual update / organization task

### AIP_LOCAL
Dùng cho local/private note khi thật sự cần.

---

## 9. Step 5 — Draft using correct template

Use:
- `aip_templates/AIP_ROOT_TEMPLATE_MVP.md`
- `aip_templates/AIP_PLAN_TEMPLATE_MVP.md`
- `aip_templates/AIP_EXEC_TEMPLATE_MVP.md`
- `aip_templates/AIP_LOCAL_TEMPLATE_MVP.md`

---

## 10. Step 6 — Review readiness

### PLAN readiness
Một PLAN đủ tốt khi có thể handoff cho EXEC mà không cần re-plan từ đầu.

### EXEC readiness
Một EXEC đủ tốt khi:
- không mơ hồ objective/scope chính
- references đủ rõ
- step execution có thể materialize thành Active Step Context

---

## 11. Naming rule

### AIP_PLAN
`AIP-PLAN-<NNN>-<slug>.md`

### AIP_EXEC
`AIP-EXEC-<NNN>-<slug>.md`

### AIP_LOCAL
`AIP-LOCAL-<NNN>-<slug>.md`

### AIP_ROOT
`AIP_ROOT.md` hoặc `AIP-ROOT.md` theo convention project đã chọn  
(MVP package khuyến nghị giữ `AIP_ROOT.md` trong `truth/`)

---

## 12. Output of this guide

Khi dùng xong guide này, AI nên có:
- loại AIP đã chốt
- understanding draft
- clarified scope/output
- draft AIP bám template đúng
