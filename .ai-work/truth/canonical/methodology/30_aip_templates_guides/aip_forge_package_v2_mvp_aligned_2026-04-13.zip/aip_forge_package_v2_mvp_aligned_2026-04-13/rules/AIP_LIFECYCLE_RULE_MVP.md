# AIP Lifecycle Rule for MVP
Version: 2.0  
Date: 2026-04-13

## 1. Purpose
Simple lifecycle rule aligned with MVP.

---

## 2. Status model
Use:
- `draft`
- `active`
- `done`
- `archived`

## 3. Meanings

### draft
Being written/refined.

### active
Current AIP in use.

### done
AIP has served its purpose and execution/planning is considered complete.

### archived
No longer current; retained for trace/history only.

---

## 4. Reading priority for AI
Prefer:
1. active
2. draft (if active not available and task is in creation/review)
3. done/archived only when tracing history or explicitly requested

---

## 5. Rule
MVP does not need the older Draft → Review → Active → Obsolete → Archived lifecycle if that adds friction.
Keep it simple unless the project explicitly needs more states.
