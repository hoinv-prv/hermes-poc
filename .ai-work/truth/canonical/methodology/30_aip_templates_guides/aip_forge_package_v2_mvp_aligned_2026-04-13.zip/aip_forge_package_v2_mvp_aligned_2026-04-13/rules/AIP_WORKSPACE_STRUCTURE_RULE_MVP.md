# AIP Workspace Structure Rule for MVP
Version: 2.0  
Date: 2026-04-13

## 1. Purpose
Define where AIP and workspace artifacts live in the MVP deployment model.

---

## 2. Root rule
All AI collaboration artifacts live under:

`.ai-work/`

---

## 3. AIP placement
- `truth/AIP_ROOT.md`
- `aip/plans/`
- `aip/exec/`
- `aip/local/`

---

## 4. Workspace placement
Runtime task workspace lives under:

`.ai-work/workspaces/TASK-<task-id>/`

---

## 5. Core rule
- AIP = stable control artifact
- Workspace = runtime execution state

Do not mix them.
Do not store runtime queue/findings/open questions inside AIP.

---

## 6. Active Step Context
Active Step Context belongs to Workspace, not to AIP root folders.
