---
artifact_type: aip_plan
artifact_id: AIP-PLAN-001
title: <title>
status: draft
project: <project-name>
owner: <optional>
root_aip: AIP-ROOT
updated_at: YYYY-MM-DD
---

# AIP_PLAN — <title>

## Objective
Mô tả mục tiêu planning của task/workstream này.

## Background / Context
- Task này xuất phát từ đâu?
- Vì sao cần làm bây giờ?
- Ai sẽ dùng output?

## Scope
### In Scope
- ...

### Out of Scope
- ...

## Expected Outputs
- Output 1:
- Output 2:

## References to Read First
- `truth/...`
- `wiki/...`
- `procedural/...`

## Assumptions / Constraints
- ...

## Open Questions / Risks
- OQ-01:
- OQ-02:

## Execution Steps

### Step: STEP-01 — <step title>
Objective:
...

Recommended Mode:
Planning

Applicable Guidelines:
- ...

Recommended Skills:
- ...

Inputs:
- ...

Expected Outputs:
- ...

Done Condition:
...

Notes / Constraints:
...

Workspace Actions:
- ...

### Step: STEP-02 — <step title>
Objective:
...

Recommended Mode:
Research

Applicable Guidelines:
- ...

Recommended Skills:
- ...

Inputs:
- ...

Expected Outputs:
- ...

Done Condition:
...

Notes / Constraints:
...

Workspace Actions:
- ...

## Done Criteria
- [ ] Scope đủ rõ
- [ ] Output đủ rõ
- [ ] References to read first đã rõ
- [ ] Execution skeleton đủ để chuyển sang EXEC
- [ ] Review points đã được nêu rõ

## Review Points
- ...
- ...

## Handoff to EXEC
Tối thiểu phải bàn giao:
- objective
- scope / non-scope
- expected outputs
- references to read first
- task step skeleton
- open questions
- risks / constraints
- done criteria
- review points
