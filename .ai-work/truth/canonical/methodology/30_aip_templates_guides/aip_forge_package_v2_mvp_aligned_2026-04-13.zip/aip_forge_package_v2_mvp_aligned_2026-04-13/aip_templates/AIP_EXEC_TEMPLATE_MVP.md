---
artifact_type: aip_exec
artifact_id: AIP-EXEC-001
title: <title>
status: draft
project: <project-name>
owner: <optional>
root_aip: AIP-ROOT
plan_source: AIP-PLAN-001
updated_at: YYYY-MM-DD
---

# AIP_EXEC — <title>

## Objective
Mô tả mục tiêu execution của task/workstream này.

## Execution Scope
### In Scope
- ...

### Out of Scope
- ...

## Expected Outputs
- Output 1:
- Output 2:

## References to Read First
- `truth/...`
- `wiki/...`
- `procedural/...`
- `aip/plans/AIP-PLAN-...` (nếu có)

## Current Risks / Constraints
- ...

## Execution Steps

### Step: STEP-01 — <step title>
Objective:
...

Recommended Mode:
Executing

Applicable Guidelines:
- ...

Recommended Skills:
- ...

Inputs:
- ...

Expected Outputs:
- ...

Done Condition:
...

Notes / Constraints:
...

Workspace Actions:
- update active step context
- update queue/findings/open questions
- update draft output
- capture candidate if needed

### Step: STEP-02 — <step title>
Objective:
...

Recommended Mode:
Reviewing

Applicable Guidelines:
- ...

Recommended Skills:
- ...

Inputs:
- ...

Expected Outputs:
- ...

Done Condition:
...

Notes / Constraints:
...

Workspace Actions:
- self-review
- update draft/final output
- raise wiki/update candidate if needed

## Done Criteria
- [ ] Output đúng loại, đúng scope
- [ ] Output bám PLAN handoff hoặc direct execution justification
- [ ] Open points không còn bị che giấu
- [ ] Final output sẵn sàng cho downstream / review

## Review / Finalization Notes
- ...
- ...

## Re-plan Rule
Nếu cần thay đổi macro scope hoặc expected output:
- không silently drift
- tạo explicit re-plan / update AIP
