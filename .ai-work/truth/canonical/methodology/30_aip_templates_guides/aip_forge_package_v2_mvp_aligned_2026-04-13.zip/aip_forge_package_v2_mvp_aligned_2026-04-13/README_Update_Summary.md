# AIP Forge Package — MVP Aligned Update Summary
Version: 2.0  
Date: 2026-04-13

## Mục đích
Đây là bản update rút gọn từ package AIP version cũ, đã align với design mới của **AI Work System MVP**.

## Phạm vi update trong package này
Package này tập trung update:
- **AIP templates**
- **Q&A flow / question list để tạo AIP**
- **một số rule cốt lõi liên quan đến lifecycle / workspace / type mapping**
- **skill create-aip** theo worldview mới

## Những thay đổi lớn so với version cũ

### 1. AIP được chốt là:
**AI Implementation Plan**

Không dùng “AI Instruction Plan” như cách hiểu cũ.

### 2. AIP types trong MVP được rút gọn thành:
- `AIP_ROOT`
- `AIP_PLAN`
- `AIP_EXEC`
- optional `AIP_LOCAL`

Các nhánh cũ như:
- Shared
- PM
- Member
- META

không còn là trục chính của MVP package này.

### 3. AIP type và Mode là hai trục khác nhau
- **AIP type** = phase/control intent
- **Mode** = reasoning posture

### 4. AIP là stable artifact
- không dùng AIP làm runtime notebook
- findings / queue / open questions không sống trong AIP
- runtime state sống trong Workspace

### 5. Active Step Context được thêm vào worldview mới
- AI không cần đọc full AIP ở mỗi step
- step hiện tại nên được materialize thành **Active Step Context**
- ưu tiên skill + script deterministic để generate

### 6. Root entry flow mới
AI khởi động theo:
**SOP → AI Work Contract → AIP_ROOT → task AIP → Active Step Context**

### 7. Wiki-first / Workspace-based model
AIP mới được thiết kế để phối hợp tốt với:
- Truth
- Wiki
- History
- Workspace
- Queue
- Capture Inbox

## Package này không làm gì
- không migrate toàn bộ package cũ
- không update mọi sample cũ
- không thêm SeedPath
- không thêm multi-agent / advanced orchestration

## Nội dung package
- `aip_templates/`
- `guides/`
- `rules/`
- `skills/create-aip/`

## Khuyến nghị dùng
Dùng package này như:
- baseline mới để review template
- base để update skill tạo AIP
- base để tạo package full v2 sau khi review xong
