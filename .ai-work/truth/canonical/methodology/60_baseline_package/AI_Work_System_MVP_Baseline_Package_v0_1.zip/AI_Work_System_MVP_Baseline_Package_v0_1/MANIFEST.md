# Manifest

Package contains baseline `.ai-work/` deployment starter kit.
