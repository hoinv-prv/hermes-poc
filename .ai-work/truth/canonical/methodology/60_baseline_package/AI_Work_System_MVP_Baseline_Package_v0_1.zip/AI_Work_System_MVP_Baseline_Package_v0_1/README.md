# AI Work System MVP Baseline Package
Version: 0.1

## Purpose
Starter kit để deploy **AI Work System MVP** vào một dự án phần mềm theo mô hình đã chốt.

## What is included
- `.ai-work/` root folder
- `truth/`, `aip/`, `procedural/`, `wiki/`, `history/`, `workspace_templates/`, `workspaces/`, `tooling/`
- baseline root docs
- AIP templates
- minimal procedural docs
- workspace template
- tooling skeleton scripts

## Deployment
Copy folder `.ai-work/` vào **project root** của dự án phần mềm.

## Recommended startup reading order for AI
1. `.ai-work/truth/SOP_MASTER.md`
2. `.ai-work/truth/AI_WORK_CONTRACT.md`
3. `.ai-work/truth/AIP_ROOT.md`
4. task-specific `.ai-work/aip/plans/...` or `.ai-work/aip/exec/...`
5. workspace active step context if task uses workspace

## Notes
This is a **baseline package**, not a finished implementation.
Use it as a starting point and refine per project.
