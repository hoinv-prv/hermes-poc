---
name: create-aip
description: Create an AIP aligned with AI Work System MVP
user-invocable: true
---

# SKILL: create-aip

## Purpose
Create an AIP aligned with:
- SOP-first
- AI Work Contract
- AIP_ROOT / PLAN / EXEC / LOCAL
- Active Step Context
- Workspace-based execution
- Wiki-first knowledge usage

## Inputs
- task/request
- truth/SOP_MASTER.md
- truth/AI_WORK_CONTRACT.md
- truth/AIP_ROOT.md
- relevant truth/wiki refs if available

## Outputs
- chosen AIP type
- clarified understanding draft
- drafted AIP content
- unresolved questions if any

## Flow
1. Infer task understanding draft
2. Decide if AIP is needed
3. Choose AIP type
4. Ask minimal clarification if needed
5. Select template
6. Draft AIP
7. Self-check

## Rules
- If uncertain between PLAN and EXEC → choose PLAN
- Do not create overly large AIPs
- AIP is stable control, not runtime notebook
- Each step should be materializable into Active Step Context
