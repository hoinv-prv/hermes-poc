---
artifact_type: truth_doc
title: SOP Master
status: active
updated_at: YYYY-MM-DD
---

# SOP_MASTER

## Purpose
Mô tả SOP chuẩn của BrSE / tổ chức mà AI phải làm việc theo.

## Scope
- SOP áp dụng cho project / nhóm công việc nào
- Phase / checkpoint / review / approval nào là chuẩn

## Core Rules
- AI phải làm việc trong SOP này
- Nếu task vượt ngoài scope hoặc cần đổi SOP, phải confirm với người dùng

## Review / Approval Points
- ...

## Notes
- Replace this baseline with project-specific SOP.
