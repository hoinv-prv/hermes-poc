---
artifact_type: wiki_entry
entry_type: reference
artifact_id: WIKI-GLOSSARY-001
title: Glossary
knowledge_class: reference
use_rule: verify_before_use
status: active
canonical_references: []
last_verified_at: YYYY-MM-DD
updated_at: YYYY-MM-DD
---

# Glossary

## Purpose
Nơi giữ glossary / terminology chung cho project.

## Scope
Terms useful for AI and humans.

## Canonical References
- add when available

## Recommended Next Reads
- `wiki/domain/README.md`

## Notes
- Start small and grow carefully.
