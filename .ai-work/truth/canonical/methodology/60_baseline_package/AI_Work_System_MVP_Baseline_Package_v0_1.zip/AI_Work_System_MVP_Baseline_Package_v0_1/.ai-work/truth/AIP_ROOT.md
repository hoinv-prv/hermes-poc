---
artifact_type: aip_root
artifact_id: AIP-ROOT
title: Project Root AIP
status: active
project: <project-name>
updated_at: YYYY-MM-DD
---

# AIP_ROOT

## Objective
Mục tiêu AI working ở mức project.

## Project Scope
### In Scope
- ...

### Out of Scope
- ...

## Project Priorities
- ...
- ...

## Core References
- `truth/SOP_MASTER.md`
- `truth/AI_WORK_CONTRACT.md`
- ...

## Constraints / Assumptions
- ...

## Notes
- Task-level AIPs phải bám file này.
