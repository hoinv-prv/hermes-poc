---
artifact_type: active_step_context
artifact_id: ASC-<task-id>-<step-id>
task_id: TASK-<task-id>
source_aip: AIP-PLAN-001
step_id: STEP-01
status: active
updated_at: YYYY-MM-DD
---

# Active Step Context

## Step ID / Step Title
- ...

## Source AIP
- ...

## Objective
...

## Recommended Mode
...

## Applicable Guidelines
- ...

## Recommended Skills
- ...

## Inputs
- ...

## Expected Outputs
- ...

## Done Condition
...

## Notes / Constraints
- ...

## Relevant Queue Item IDs
- ...

## Relevant Finding IDs
- ...

## Relevant Open Question IDs
- ...

## Active References
- ...
