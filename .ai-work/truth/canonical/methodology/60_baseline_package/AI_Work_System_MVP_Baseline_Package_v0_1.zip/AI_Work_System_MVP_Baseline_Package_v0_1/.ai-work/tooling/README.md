# tooling/

Deterministic-first scripts for AI Work System MVP.

Included skeleton tools:
- build_active_step_context.py
- set_current_step.py
- init_workspace.py
- lint_aip.py
- lint_workspace.py
- lint_wiki.py

These are baseline skeletons only.
