# canonical/

Dùng để chứa:
- canonical design docs
- approved canonical summaries
- các tài liệu authoritative khác phục vụ AI

Rule:
- không dùng folder này như nơi lưu draft notes
- update có kiểm soát
