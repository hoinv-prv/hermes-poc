# Task Brief

## Task ID
TASK-YYYYMMDD-<slug>

## Goal
...

## Expected Output
...

## Primary Mode
...

## Supporting Modes
...

## Scope Notes
...

## Current Status
...
