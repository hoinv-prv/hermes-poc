---
artifact_type: aip_plan
artifact_id: AIP-PLAN-001
title: <title>
status: draft
project: <project-name>
owner: <optional>
root_aip: AIP-ROOT
updated_at: YYYY-MM-DD
---

# AIP_PLAN — <title>

## Task Classification
- Why PLAN is used:
- Expected next artifact:
  - [ ] AIP_EXEC
  - [ ] direct execution without separate EXEC
  - [ ] not decided yet

## Objective
...

## Background / Context
- ...

## Scope
### In Scope
- ...

### Out of Scope
- ...

## Expected Outputs
- ...

## References to Read First
### Truth First
- ...

### Wiki First
- ...

### Optional Supporting Refs
- ...

## Assumptions / Constraints
- ...

## Open Questions
- ...

## Risks / Constraints
- ...

## Execution Steps

### Step: STEP-01 — <step title>
Objective:
...

Recommended Mode:
Planning

Applicable Guidelines:
- ...

Recommended Skills:
- ...

Inputs:
- ...

Expected Outputs:
- ...

Step Output / Execution Artifact:
- ...

Done Condition:
...

Notes / Constraints:
...

Workspace Actions:
- ...

## Done Criteria
- [ ] Scope đủ rõ
- [ ] Output đủ rõ
- [ ] Execution skeleton đủ để chuyển sang EXEC

## Review Points
- ...

## Handoff to EXEC
- objective
- scope / non-scope
- expected outputs
- refs
- step skeleton
- open questions
- risks / constraints
- done criteria
- review points
