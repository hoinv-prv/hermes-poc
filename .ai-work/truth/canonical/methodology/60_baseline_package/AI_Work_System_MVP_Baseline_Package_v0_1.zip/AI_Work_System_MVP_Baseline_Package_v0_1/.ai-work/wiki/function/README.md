# function/

Place `function` wiki entries here.

Core required sections for important entries:
- Purpose
- Scope
- Canonical References
- Recommended Next Reads
