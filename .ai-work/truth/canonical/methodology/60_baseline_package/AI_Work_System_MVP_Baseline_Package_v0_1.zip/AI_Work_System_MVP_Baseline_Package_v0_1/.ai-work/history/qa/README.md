# qa/

History zone for `qa`.
Use for trail / archive / evidence, not as primary truth.
