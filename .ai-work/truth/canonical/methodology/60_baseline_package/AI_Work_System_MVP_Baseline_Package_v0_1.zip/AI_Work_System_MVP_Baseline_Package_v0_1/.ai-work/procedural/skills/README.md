# skills/

Place execution-support skill docs here.

Skills are not AIP and not Playbooks.
They support micro-execution of a step.
