# Wiki Authoring Guideline

## Core model
Wiki is curated + guidance-centric.
It is not the same as Truth and not the same as History.

## Required core sections
- Purpose
- Scope
- Canonical References
- Recommended Next Reads

## Metadata for important entries
- artifact_type
- entry_type
- artifact_id
- title
- knowledge_class
- use_rule
- status
- canonical_references
- last_verified_at
- updated_at

## Staleness
Use status:
- active
- needs_review
