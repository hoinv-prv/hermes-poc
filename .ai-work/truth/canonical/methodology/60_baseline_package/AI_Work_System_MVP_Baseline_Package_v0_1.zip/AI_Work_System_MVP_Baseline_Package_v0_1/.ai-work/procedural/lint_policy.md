# Lint Policy

## Default MVP lint scope
- structural lint
- reference lint
- metadata lint

## Applies to
- AIP
- Workspace
- Queue
- Capture Inbox
- Wiki

## Not default
- deep semantic lint
- auto rewrite of official content

## Exception
Light semantic / consistency lint only when explicitly requested.
