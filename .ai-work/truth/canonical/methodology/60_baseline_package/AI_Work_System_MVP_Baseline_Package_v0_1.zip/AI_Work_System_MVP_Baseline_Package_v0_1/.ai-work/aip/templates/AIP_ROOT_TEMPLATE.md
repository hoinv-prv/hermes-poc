---
artifact_type: aip_root
artifact_id: AIP-ROOT
title: Project Root AIP
status: active
project: <project-name>
updated_at: YYYY-MM-DD
---

# AIP_ROOT — Project Root AIP

## Objective
...

## Project Scope
### In Scope
- ...

### Out of Scope
- ...

## Project Priorities
- ...

## Core References
- ...

## Constraints / Assumptions
- ...

## Notes
- ...
