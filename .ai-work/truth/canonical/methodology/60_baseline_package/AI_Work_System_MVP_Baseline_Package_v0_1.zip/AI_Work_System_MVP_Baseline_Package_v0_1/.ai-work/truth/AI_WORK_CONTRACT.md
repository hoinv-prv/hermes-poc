---
artifact_type: truth_doc
title: AI Work Contract
status: active
updated_at: YYYY-MM-DD
---

# AI_WORK_CONTRACT

## Purpose
Working agreement giữa người dùng và AI trong khuôn khổ SOP.

## Contract Rules
- Bám SOP trước
- Bám AIP trước khi đi vào runtime artifacts
- Không silently drift khỏi scope
- Không auto rewrite Truth / official Wiki
- Runtime state sống trong Workspace, không sống trong AIP

## Artifact Precedence
SOP → AI Work Contract → AIP_ROOT → AIP_PLAN / AIP_EXEC → Guidelines / Playbooks → Skills → Wiki → Workspace

## Workspace Rule
Task phức tạp phải dùng Workspace.

## Curation Rule
Capture first, curate later.

## Notes
- Replace / refine this baseline with project-specific contract wording if needed.
