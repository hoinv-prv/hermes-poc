# workspaces/

Place runtime task workspaces here.

Suggested task id format:
TASK-YYYYMMDD-<short-slug>
