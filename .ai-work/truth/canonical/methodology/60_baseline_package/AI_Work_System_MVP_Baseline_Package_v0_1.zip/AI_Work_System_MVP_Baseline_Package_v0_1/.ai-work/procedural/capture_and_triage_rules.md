# Capture and Triage Rules

## Principle
Capture first, curate later.

## Flow
Runtime discoveries → Capture Inbox → Triage → Promote / Archive / Discard

## Safety rules
- do not promote directly to Truth by default
- if unsure between Curated and Reference → choose Reference
- if unsure between Curated and Truth → choose Curated
