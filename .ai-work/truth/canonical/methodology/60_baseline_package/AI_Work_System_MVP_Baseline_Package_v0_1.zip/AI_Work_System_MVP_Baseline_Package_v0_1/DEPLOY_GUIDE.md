# Deploy Guide — AI Work System MVP Baseline Package

## Step 1
Copy `.ai-work/` to your software project root.

## Step 2
Replace baseline contents in:
- `.ai-work/truth/SOP_MASTER.md`
- `.ai-work/truth/AI_WORK_CONTRACT.md`
- `.ai-work/truth/AIP_ROOT.md`

## Step 3
Review and adapt:
- `.ai-work/procedural/`
- `.ai-work/wiki/`
- `.ai-work/workspace_templates/`
- `.ai-work/tooling/`

## Step 4
Create first task AIP:
- use `.ai-work/aip/templates/AIP_PLAN_TEMPLATE.md`
- or `.ai-work/aip/templates/AIP_EXEC_TEMPLATE.md`

## Step 5
Create first workspace:
- manually from template
- or later via `tooling/init_workspace.py`

## Note
This package is intentionally conservative and starter-oriented.
